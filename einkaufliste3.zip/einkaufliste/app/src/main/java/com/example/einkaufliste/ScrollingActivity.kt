package com.example.einkaufliste

import android.os.Bundle
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.example.einkaufliste.adapter.ShoppingAdapter
import com.example.einkaufliste.data.AppDatabase
import com.example.einkaufliste.data.ShoppingItem
import com.example.einkaufliste.databinding.ActivityScrollingBinding

class ScrollingActivity : AppCompatActivity(), ShoppingItemDialog.ShoppingItemDialogHandler {

    private lateinit var adapter: ShoppingAdapter
    private lateinit var binding: ActivityScrollingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityScrollingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbarLayout.title=title

        Thread{
            var itemsList = AppDatabase.getInstance(this@ScrollingActivity).ShoppingItemDao().getAllShoppingItems()

            runOnUiThread{
                adapter = ShoppingAdapter(this,itemsList)
                binding.recyclerShopping.adapter = adapter

                binding.fab.setOnClickListener { view ->
                    ShoppingItemDialog().show(supportFragmentManager, "TAG")
                }
            }
        }.start()
    }
    override fun shoppingItemCreated(item: ShoppingItem) {
        Thread{
            AppDatabase.getInstance(this@ScrollingActivity).ShoppingItemDao().insertShoppingItem(item)

            runOnUiThread{
                adapter.addItem(item)
            }
        }.start()
        adapter.addItem(item)
    }

}