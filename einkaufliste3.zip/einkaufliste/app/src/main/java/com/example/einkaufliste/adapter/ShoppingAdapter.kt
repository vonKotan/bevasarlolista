package com.example.einkaufliste.adapter


import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.einkaufliste.R
import com.example.einkaufliste.ScrollingActivity
import com.example.einkaufliste.data.AppDatabase
import com.example.einkaufliste.data.ShoppingItem
import com.example.einkaufliste.databinding.ActivityScrollingBinding
import com.example.einkaufliste.databinding.ShopItemBinding


class ShoppingAdapter :RecyclerView.Adapter<ShoppingAdapter.ViewHolder> {

    private lateinit var binding: ShopItemBinding
    private val items= mutableListOf<ShoppingItem>(
        ShoppingItem(null, "kenyer",300,"ááááá",false),
        ShoppingItem(null, "tojas",500,"segítség",false)
    )
    private val context: Context

    constructor(context: Context, itemsList: List<ShoppingItem>): super(){
        this.context=context
        items.addAll(itemsList)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = ShopItemBinding.inflate(
            LayoutInflater.from(context), parent, false
        )
        return ViewHolder(binding.root)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[holder.adapterPosition])
        binding.cancel.setOnClickListener{
            deleteItem(holder.adapterPosition)
        }
    }

    private fun deleteItem(adapterPosition:Int){
        var shoppingItemToDelete=items.get(adapterPosition)
        Thread{
            AppDatabase.getInstance(context).ShoppingItemDao().deleteShoppingItem(shoppingItemToDelete)

            (context as ScrollingActivity).runOnUiThread{
                items.removeAt(adapterPosition)
                notifyItemRemoved(adapterPosition)
            }
        }.start()
        //items.removeAt(adapterPosition)
        //notifyItemRemoved(adapterPosition)
    }

    override fun getItemCount(): Int{
        return items.size
    }

    fun addItem(item: ShoppingItem){
        items.add(item)
        notifyItemInserted(items.lastIndex)
    }

    fun deleteAll(){
        items.clear()
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        fun bind(shopItem: ShoppingItem){
            binding.name.text= shopItem.name
            binding.price.text=shopItem.price.toString()
            binding.leiras.text=shopItem.description
           /* when(shopItem.description){

            }*/
        }
    }

}