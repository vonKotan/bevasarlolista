
package com.example.einkaufliste

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.einkaufliste.data.ShoppingItem
import com.example.einkaufliste.databinding.ShoppingDialogBinding
import java.lang.RuntimeException


class ShoppingItemDialog : DialogFragment(){
    private lateinit var dialogBinding : ShoppingDialogBinding

    interface  ShoppingItemDialogHandler{
        fun shoppingItemCreated(item: ShoppingItem)
    }

    lateinit var shoppingItemHandler:ShoppingItemDialogHandler

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if(context is ShoppingItemDialogHandler){
            shoppingItemHandler=context
        }else{
            throw RuntimeException(
                "baj van tesó"
            )
        }
    }

    private lateinit var etName: EditText
    private lateinit var etLeiras: EditText
    private lateinit var  etPrice: EditText

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())

        builder.setTitle("New Item")
        val rootView = requireActivity().layoutInflater.inflate(
            R.layout.shopping_dialog, null
        )

        // Initialize dialogBinding with the inflated view
        dialogBinding = ShoppingDialogBinding.bind(rootView)

        etName = dialogBinding.etNev
        etPrice = dialogBinding.etPenz
        etLeiras = dialogBinding.etLe

        builder.setView(rootView)
        builder.setPositiveButton("OK") { dialog, which -> }
        return builder.create()
    }


    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE)

        positiveButton.setOnClickListener{
            if( etName.text.isNotEmpty()){
                if (etPrice.text.isNotEmpty()){
                    handleItemCreate()

                    dialog.dismiss()
                }else{
                    etPrice.error="Kötelezö kitölteni"
                }
            }else{
                etName.error="Kötelezö kitölteni"
            }
        }
    }
    fun handleItemCreate(){
        shoppingItemHandler.shoppingItemCreated(
            ShoppingItem(
                null,
                etName.text.toString(),
                etPrice.text.toString().toInt(),
                etLeiras.text.toString(),
                false
            )
        )
    }
}