package com.example.einkaufliste.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ShoppingItemDAO {
    @Query("SELECT*FROM EShoppingItem")
    fun getAllShoppingItems(): List<ShoppingItem>

    @Insert
    fun insertShoppingItem(vararg shoppingItem: ShoppingItem)

    @Delete
    fun deleteShoppingItem(shoppingItem: ShoppingItem)
}