package com.example.einkaufliste.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="EShoppingItem")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val EShoppingItemId: Long?,
    @ColumnInfo(name="name") var name: String,
    @ColumnInfo(name="price") var price: Int,
    @ColumnInfo(name="description") var description: String,
    @ColumnInfo(name="bought") var bought: Boolean
) {
}